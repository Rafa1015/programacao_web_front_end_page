# atv02-responsive-design

Projeto inicial com HTML básico, includes e imagens. 
Consulte o enunciado da atividade no Moodle para mais instruções.
